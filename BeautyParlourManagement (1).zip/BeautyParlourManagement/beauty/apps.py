from django.apps import AppConfig


class BeautyConfig(AppConfig):
    name = 'beauty'
